Gold = {}
Gold.Name = "Gold!"
Gold.Version = "Alpha 0.1"
Gold.Author = "N1nja2na"

--Variables
goldEarned = 0
goldLost = 0
originalGold = 0;
isStarting = true;
totalGold = 0
hidden = false





--Functions
function Gold.updateMoney(eventCode, newMoney, oldMoney, reason)
	
	if reason == 42 or reason == 43 then return end --If deposit or withdrawl from bank
	
	
	
	diff = newMoney - oldMoney --Get the change
 	if diff > 0 then --Is the change positive?
		goldEarned = goldEarned + diff --You've gained
	end
	if diff < 0 then --Is the change negative?
		goldLost = goldLost - diff --You've lost
	end
	totalGold = totalGold + diff --sum the total with the difference
	Gold.updateText() --Update the ui
end

function Gold.updateText()
	gold:SetScale(0.7)
	gold:SetText(string.format("Original Gold: %s \nGold Earned: %s -- Gold Lost: %s\nProfit\/Loss: %s", comma_value(originalGold), comma_value(goldEarned), comma_value(goldLost), comma_value(totalGold))) --Sets the text
	--gold:SetText(string.format("Gold Change: %s", comma_value((GetGold() - originalGold))))
end

function Gold.beginInit()
	CHAT_SYSTEM:AddMessage("Initializing...")
	originalGold = GetGold()
	Gold.updateText()
	CHAT_SYSTEM:AddMessage("Finished Initializing.")
	EVENT_MANAGER:RegisterForEvent("Gold!", EVENT_MONEY_UPDATE, Gold.updateMoney ) --Anytime the gold amount changes, update it
	return 0;
end

function Gold.toggleGoldWindow() --Toggles the ui
	hidden = not hidden --false = true; true = false
	GoldTracker:SetHidden(hidden) --Set hidden to whichever
end


function Gold.getGold() --Get the current gold
	return GetCurrentMoney()
end

function comma_value(amount) --found at http://lua-users.org/wiki/FormattingNumbers
	  local formatted = amount
	  while true do
	    formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')
	    if (k==0) then
	      break
	    end
	  end
	  return formatted
end

--Events

EVENT_MANAGER:RegisterForEvent("Gold!", EVENT_ADD_ON_LOADED, Gold.beginInit ) --On start

--Commands
SLASH_COMMANDS["/togglegold"] = Gold.toggleGoldWindow --Toggles the ui with /togglegold
SLASH_COMMANDS["/reinit"] = Gold.beginInit
