Gold = {}
Gold.Name = "Gold!"
Gold.Version = "Alpha 0.3"
Gold.Author = "N1nja2na"

--Variables
local goldEarned = 0
local goldLost = 0
local originalGold = 0
local isStarting = true
local totalGold = 0
local hidden = false

local moneyReasonsAmount = {0, 0, 0, 0, 0, 0, 0, 0, 0 }
local moneyReasonsText =
{
	"Bought/Sold From Merchant",
	"Bought From Guild Store",
	"Upgraded Horse",
	"Repaired Equipment",
	"Withdrew From Mail",
	"Sent Via Mail",
	"Guild Bank Deposit",
	"Guild Bank Withdrawl",
	"Upgraded Backpack"
}

function Gold.manageMoneyReasons(reason, diff)
	--1 merchant buy sell
	--31 guild store buy
	--28 horse merchant
	--29 repair
	--2 mail deposit withdraw
	--51 Deposit to guild bank
	--52 Withdraw from guild bank
	--8 Pack merchant




	--REASON IS WITHDRAWING OR DEPOSITING FROM BANK
	if reason == 41 or reason == 43 then return -1  
	
	
	elseif reason == 1 then
		d("Bought/Sold From Merchant")
		moneyReasonsAmount[1] = moneyReasonsAmount[1] + diff
	
	elseif reason == 31 then
		d("Bought From Guild Store")
		moneyReasonsAmount[2] = moneyReasonsAmount[2] + diff
	
	elseif reason == 28 then
		d("Upgraded Mount")
		moneyReasonsAmount[3] = moneyReasonsAmount[3] + diff
	
	elseif reason == 29 then 
		d("Repaired Armor")
		moneyReasonsAmount[4] = moneyReasonsAmount[4] + diff
	
	elseif reason == 2 then
		if diff > 0 then
			d("Withdrew From Mail")
			moneyReasonsAmount[5] = moneyReasonsAmount[5] + diff
		
		elseif diff < 0 then
			d("Sent Via Mail")
			moneyReasonsAmount[6] = moneyReasonsAmount[6] + diff
		end
	
	elseif reason == 51 then
		d("Deposit To Guild Bank")
		moneyReasonsAmount[7] = moneyReasonsAmount[7] + diff
	
	elseif reason == 52 then
		d("Withdrawl From Guild Bank")
		moneyReasonsAmount[8] = moneyReasonsAmount[8] + diff
	
	elseif reason == 8 then
		d("Upgraded Backpack")
		moneyReasonsAmount[9]= moneyReasonsAmount[9] + diff
	end
	
	return 0
	
end

--Functions
function Gold.updateMoney(eventCode, newMoney, oldMoney, reason)
	
	--if reason == 42 or reason == 43 then return end --If deposit or withdrawl from bank
	
	d(reason) 
	diff = newMoney - oldMoney --Get the change
	
	local isReasonOkay = Gold.manageMoneyReasons(reason, diff)
	if isReasonOkay == -1 then return end
	
	
	
 	if diff > 0 then --Is the change positive?
		goldEarned = goldEarned + diff --You've gained
	end
	if diff < 0 then --Is the change negative?
		goldLost = goldLost - diff --You've lost
	end
	totalGold = totalGold + diff --sum the total with the difference
	Gold.updateText() --Update the ui
end

function Gold.updateText()
	gold:SetScale(0.7)
	gold:SetText(string.format("Gold Earned: %s -- Gold Lost: %s\nOriginal Gold: %s -- New Total: %s\nProfit/Loss: %s", comma_value(goldEarned), comma_value(goldLost), comma_value(originalGold), comma_value(originalGold + totalGold), comma_value(totalGold)))
	
	goldDetails:SetScale(0.7)
	
	local details = ""
	for i = 1, 9 do
		--d(moneyReasonsAmount[i])
		--details = string.gsub(details, moneyReasonsText[i], moneyReasonsAmount[i])
		details = details .. string.format("%s: %s\n", moneyReasonsText[i], comma_value(moneyReasonsAmount[i]))
	end
	
	
	goldDetails:SetText(details)
end

function Gold.beginInit()
	CHAT_SYSTEM:AddMessage("Initializing...")
	originalGold = GetGold()
	Gold.updateText()
	CHAT_SYSTEM:AddMessage("Finished Initializing.")
	EVENT_MANAGER:RegisterForEvent("Gold!", EVENT_MONEY_UPDATE, Gold.updateMoney ) --Anytime the gold amount changes, update it
	GoldDetailedTracker:SetHidden(true)
	return 0;
end


    

function Gold.ReloadUIShortHand()
	StartChatInput("/reloadui")
	CHAT_SYSTEM:SubmitTextEntry()
end


--SLASH_COMMANDS["/goldtest1"] = Gold.playerActivate
SLASH_COMMANDS["/r"] = Gold.ReloadUIShortHand



function Gold.toggleGoldWindow() --Toggles the ui
	hidden = not hidden --false = true; true = false
	GoldTracker:SetHidden(hidden) --Set hidden to whichever
end

function Gold.toggleGoldaDetailsWindow()
	GoldDetailedTracker:SetHidden(not GoldDetailedTracker:IsHidden())
end


function Gold.getGold() --Get the current gold
	return GetCurrentMoney()
end

function comma_value(amount) --found at http://lua-users.org/wiki/FormattingNumbers
	  local formatted = amount
	  while true do
	    formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')
	    if (k==0) then
	      break
	    end
	  end
	  return formatted
end

--Bindings
ZO_CreateStringId("SI_BINDING_NAME_TOGGLE_UI", "Toggle UI")
ZO_CreateStringId("SI_BINDING_NAME_TOGGLE_DETAILS", "Toggle Detailed UI")


--Events

EVENT_MANAGER:RegisterForEvent("Gold!", EVENT_ADD_ON_LOADED, Gold.beginInit ) --On start

--Commands
SLASH_COMMANDS["/gold.toggleui"] = Gold.toggleGoldWindow --Toggles the ui with /togglegold
SLASH_COMMANDS["/gold.toggledetails"] = Gold.toggleGoldaDetailsWindow --Toggles the ui with /togglegold

SLASH_COMMANDS["/reinit"] = Gold.beginInit
