Gold = {}
Gold.Name = "Gold!"
Gold.Version = "Alpha 0.5"
Gold.Author = "N1nja2na"

--Variables
local goldEarned = 0
local goldLost = 0
local originalGold = 0
local isStarting = true
local totalGold = 0
local hidden = false


local moneyReasonsLookup =
{
	[0] = "From Chest",
	[1] = "Bought/Sold From Merchant",
	[2] = "Withdrew/Sent Via Mail",
	[4] = "Recieved Money From Quest",
	[5] = "Paid During Quest",
	[8] = "Upgraded Backpack",
	[13] = "Picked Up Loot",
	[19] = "Teleport Cost",
	[28] = "Upgraded Mount",
	[29] = "Repaired Armor",
	[31] = "Bought From Guild Store",
	[33] = "Fee For Guild Store",
	[51] = "Deposit To Guild Bank",
	[52] = "Withdrawl From Guild Bank",
	[62] = "Lockbox Loot"


}
local moneyReasons =
{
	["From Chest"] = 0,
	["Bought From Merchant"] = 0,
	["Sold To Merchant"] = 0,
	["Bought From Guild Store"] = 0,
	["Upgraded Horse"] = 0,
	["Repaired Equipment"] = 0,
	["Withdrew From Mail"] = 0,
	["Sent Via Mail"] = 0,
	["Guild Bank Deposit"] = 0,
	["Guild Bank Withdrawl"] = 0,
	["Upgraded Backpack"] = 0,
	["Recieved Money From Quest"] = 0,
	["Fee For Guild Store"] = 0,
	["Paid During Quest"] = 0,
	["Teleport Cost"] = 0,
	["Lockbox Loot"] = 0,
	["Picked Up Loot"] = 0
	
	
}

function Gold.IsLarger(diff)
	return diff > 0
end
	
function Gold.manageMoneyReasons_Loop(reason, diff)
	--0 From chest
	--1 merchant buy sell
	--2 mail deposit withdraw
	--4 recieved money from quest
	--5 paid in quest
	--8 Pack merchant
	--19 teleport
	--28 horse merchant
	--29 repair
	--31 guild store buy
	--33 Attached to guild store
	--51 Deposit to guild bank
	--52 Withdraw from guild bank
	--62 Loot from lockbox
	--13 loot
	--TO DO
	--Rewrite with another table so adding new reasons is simple and easy
	
	
	local key = ""
	local isLarger = Gold.IsLarger(diff)
	if diff == 0 or reason == 41 or reason == 43 then
		return -1 --No change
	end
	
	
	for k, v in pairs(moneyReasonsLookup) do
		if reason == k then
		
			if k == 1 then
				if isLarger then
					key = "Sold To Merchant"
				else
					key = "Bought From Merchant"
				end
			elseif k == 2 then
				if isLarger then
					key = "Withdrew From Mail"
				else
					key = "Sent Via Mail"
				end
			else
				key = v
			end
		end
	end
	
	moneyReasons[key] = moneyReasons[key] + diff --Add the new amount to the particular money reason
	
end



--Functions
function Gold.updateMoney(eventCode, newMoney, oldMoney, reason)
	--*****************************************
	-- DEBUG PRINT FOR ANY NEW REASON I FIND
				d(reason) 
	--*****************************************
	
	diff = newMoney - oldMoney --Get the change
	
	local isReasonOkay = Gold.manageMoneyReasons_Loop(reason, diff) --is this a reason we want to do things with?
	if isReasonOkay == -1 then return end --no? Then return
	
	
	
 	if diff > 0 then --Is the change positive?
		goldEarned = goldEarned + diff --You've gained
	end
	if diff < 0 then --Is the change negative?
		goldLost = goldLost - diff --You've lost
	end
	totalGold = totalGold + diff --sum the total with the difference
	Gold.updateText() --Update the ui
end

function Gold.updateText()

	--Set the scale for the gold window
	gold:SetScale(0.7)
	--Set the gold window text
	gold:SetText(string.format("Gold Earned: %s -- Gold Lost: %s\nOriginal Gold: %s -- New Total: %s\nProfit/Loss: %s", comma_value(goldEarned), comma_value(goldLost), comma_value(originalGold), comma_value(originalGold + totalGold), comma_value(totalGold)))
	
	--Set the scale for the details text
	goldDetails:SetScale(0.7)
	--Calculate the height of the details window
	local height = TableLength(moneyReasons) * 28.75
	--Set the details window height
	GoldDetailedTracker:SetHeight(height)
	
	--Details variable
	local details = ""
	
	--Print out the details
	for key, value in pairs(moneyReasons) do
		details = details .. string.format("%s: %s\n", key, comma_value(value) )
	end
	
	--Set Text
	goldDetails:SetText(details)
end

function TableLength(t)
	local length = 0
	for i in pairs(t) do length = length + 1 end
	return length
end



function Gold.SetAlpha(number, control)	
	--local dynamicControl = CreateControlFromVirtual("Gold.goldExitButton", control, "ExitButton")
	local bg = control:GetChild(1)
	local hideButton = control:GetChild(2)
	--hideButton:SetAlpha(number)
	bg:SetAlpha(number)
end

function OnAddOnLoaded(eventCode, addOnName)

	if( addOnName == "Gold") then
		Gold.beginInit()
	end
end

function Gold.beginInit()

	--Begin init
	CHAT_SYSTEM:AddMessage("Initializing...")
	originalGold = GetGold()
	Gold.updateText()
	EVENT_MANAGER:RegisterForEvent("Gold!", EVENT_MONEY_UPDATE, Gold.updateMoney ) --Anytime the gold amount changes, update it
	GoldDetailedTracker:SetHidden(true)
	
	goldCommands = {}
	goldCommands["/gold.toggleui"] = Gold.toggleGoldWindow
	goldCommands["/gold.toggledetails"] = Gold.toggleGoldDetailsWindow
	--goldCommands["/gold.displaycommands"] = Gold.displayCommands
	goldCommands["/gold.reinit"] = Gold.beginInit
	goldCommands["/goldhelp"] = Gold.displayCommands
	
	Gold.initCommands()
	CHAT_SYSTEM:AddMessage("Finished Initializing.")
	--End init
	
	--Display welcome messaage
	zo_callLater( function()d("***********************\nWelcome to Gold!\nFor help, type /goldhelp\n***********************")end, 5000 )
	
	return 0;
end


function Gold.ReloadUIShortHand()
	StartChatInput("/reloadui")
	CHAT_SYSTEM:SubmitTextEntry()
end



SLASH_COMMANDS["/rr"] = Gold.ReloadUIShortHand



function Gold.toggleGoldWindow() --Toggles the ui
	hidden = not hidden --false = true; true = false
	GoldTracker:SetHidden(hidden) --Set hidden to whichever
end

function Gold.toggleGoldDetailsWindow()
	GoldDetailedTracker:SetHidden(not GoldDetailedTracker:IsHidden())
end


function Gold.getGold() --Get the current gold
	return GetCurrentMoney()
end

function comma_value(amount) --found at http://lua-users.org/wiki/FormattingNumbers
	  local formatted = amount
	  while true do
	    formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')
	    if (k==0) then
	      break
	    end
	  end
	  return formatted
end

--Bindings
ZO_CreateStringId("SI_BINDING_NAME_TOGGLE_UI", "Toggle UI")
ZO_CreateStringId("SI_BINDING_NAME_TOGGLE_DETAILS", "Toggle Detailed UI")


--Events

EVENT_MANAGER:RegisterForEvent("Gold!", EVENT_ADD_ON_LOADED, OnAddOnLoaded ) --On start




function Gold.initCommands()
	for k,v in pairs(goldCommands) do 
		SLASH_COMMANDS[k] = v
	end
end

function Gold.displayCommands()
	d("Gold! Commands")
	d("-----------------")
	for key, value in pairs(goldCommands) do d(key) end
	d("-----------------")
end


